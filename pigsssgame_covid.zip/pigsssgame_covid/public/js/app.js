$( document ).ready(function() {
    $( "#location" ).click(function() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position){
                // console.log("Latitude: " + position.coords.latitude + "\nLongitude: " + position.coords.longitude);
                $( "#latitude").val(parseFloat(position.coords.latitude).toFixed(2));
                $( "#longitude").val(parseFloat(position.coords.longitude).toFixed(2));
            });
          } else { 
            alert("Geolocation is not supported by this browser.");
            $( "#longitude,#latitude").val(0);
          }
      });
});