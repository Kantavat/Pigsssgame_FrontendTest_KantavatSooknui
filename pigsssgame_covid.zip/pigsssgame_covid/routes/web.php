<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\dummyAPI;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
// Route::veiw('add','/');
Route::post('add',[dummyAPI::class,'add']);
Route::post('edit',[dummyAPI::class,'update']);

Route::get('/update_location',[dummyAPI::class,'update_location']);

Route::get('update_location',[dummyAPI::class,'show']);
