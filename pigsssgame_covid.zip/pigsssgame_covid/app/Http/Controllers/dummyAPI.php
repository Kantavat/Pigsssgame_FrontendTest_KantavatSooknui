<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\tests;

class dummyAPI extends Controller
{
    // function getData(){
    //     return ["name" => "anil"];
    // }

    //Get data from api
    function list($id=null){
        return $id?tests::find($id):tests::all();
    }

    //Post data API
    function add(Request $req){
       $tests = new tests;
       $tests->name = $req->name;
       $tests->age  = $req->age;
       $tests->gender = $req->gender;
       $tests->status = $req->status;
       $tests->latitude = $req->latitude;
       $tests->longitude = $req->longitude;

       $result = $tests->save();

       return redirect('/');
    //    if($result){
    //        return ["Result"=>"Data has been saved"];
    //    }
    //    else{
    //         return ["Result"=>"Operation failed"];
    //    }
    }

    //Get data
    public function show()
    {
        $data = tests::all();
        return view('update_location',['test'=> $data]);
    }

     //Post data API
     function update(Request $req){
        $data = tests::find($req->id);
        $data->latitude = $req->latitude;
        $data->longitude = $req->longitude;

        $data->save();
        return redirect('update_location');
     }

    // View page update_location
    function update_location(){
        return view('update_location');
    }



}
