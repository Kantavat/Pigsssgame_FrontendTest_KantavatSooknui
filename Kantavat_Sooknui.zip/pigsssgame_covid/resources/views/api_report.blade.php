<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Laravel</title>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    
    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet" type="text/css" >
</head>
 <!-- NAV bar -->
 <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="/">COVID19</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
  
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item ">
          <a class="nav-link" href="/">Add User <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/update_location">update_location</a>
        </li>
        <li class="nav-item ">
          <a class="nav-link " href="/infected_add">infected_add</a>
        </li>
        <li class="nav-item">
          <a class="nav-link " href="/infected_list">infected_list</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/risk_infected_add">risk_infected_add</a>
        </li>
        <li class="nav-item">
            <a class="nav-link " href="/risk_infected_list">risk_infected_list</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-primary" href="/api_report">API REPORT</a>
        </li>
    </div>
  </nav>

 
  <div class="container">
    <h1>API report</h1><br>

        <div> 
            {{-- INPUT data from DB --}}
            <input id="cur_user" type="hidden" value={{$count_rows}}>
            <input id="cur_infected" type="hidden" value={{$count_infected}}>
            
            <h3>DATE : <span id="Date"></span></h3>
            <h3>Current users : {{$count_rows}} users</h3>
            <br>
            <h3>Current noneinfection : {{$count_noninfected}}</h3>
            <h3>Current risk of infection : {{$count_riskinfected}}</h3>
            <br>
            <h3>Current infection : <span id="show_infected"></span> %</h3>
            <h3>Cumulative infection : {{$cumulative_infect}}</h3>
            
        </div>
        {{-- Infected order by infected date --}}
        <div>
            <br>
            <h3>Infected order by infected date</h3>
            <table  class="text-center">
                <th>infected</thead>
                <th>infected date</th>
                <th>Phone number</th>
                @foreach ($infected_by_date as $infected)
                    <tr>
                        <td> {{$infected['name']}}</td>
                        <td> {{$infected['updated_at']}}</td>
                        <td> {{$infected['telephone']}}</td>
                    </tr>
                @endforeach
            </table>
        </div>

        
        <div class="mb-5">
            <br>
            <h3>All current risk of infected</h3>
            <table  class="text-center">
                <th>risk of infected</th>
                <th>Phone number</th>
                @foreach ($risk_infected as $risk_infected)
                    <tr>
                        <td> {{$risk_infected['name']}}</td>
                        <td> {{$risk_infected['telephone']}}</td>
                    </tr>
                @endforeach
            </table>
        </div>
        
        
  </div>
  

   <!-- script -->
   <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
   <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
   <script type="text/javascript" src="{{ asset('js/app.js') }}"></script>