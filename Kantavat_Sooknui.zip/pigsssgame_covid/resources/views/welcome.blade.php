
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Laravel</title>
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        
        <!-- Styles -->
        <link href="{{ asset('css/app.css') }}" rel="stylesheet" type="text/css" >
       
        
    </head>
    <body>
        <!-- NAV bar -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="/">COVID19</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
          
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                  <a class="nav-link text-primary" href="/">Add User <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="/update_location">update_location</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link " href="/infected_add">infected_add</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/infected_list">infected_list</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/risk_infected_add">risk_infected_add</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/risk_infected_list">risk_infected_list</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/api_report">API REPORT</a>
                </li>
            </div>
          </nav>

        <!-- body -->
        <div class="container"> 
            
         <div class="form" >
           
            <form id="add_data"  method="post" action="add">
                @csrf
                <h1>Add User</h1>
                <div class="table text-center self-align-center">
                    <div class="row">
                        <div class="input-group mt-2 mb-1 col">
                            {{-- INPUT Username--}}
                            <div class="input-group-prepend">
                              <span class="input-group-text">NAME</span>
                            </div>
                            <input type="text" name="name" class="form-control " placeholder="Username" aria-label="Username" aria-describedby="name" required>
                        </div>
                        
                        <div class="input-group mt-2 mb-1 col">
                            {{-- INPUT phone number--}}
                            <div class="input-group-prepend">
                                <span class="input-group-text" ">Phone number</span>
                            </div>
                            <input type="text"name="telephone" class="form-control" placeholder="telephone" aria-label="telephone" aria-describedby="telephone" required>
                        </div>
                        <div class="input-group mt-2 mb-1 col">
                            {{-- INPUT Age--}}
                            <div class="input-group-prepend">
                                <span class="input-group-text" ">AGE</span>
                            </div>
                            <input type="text"name="age" class="form-control" placeholder="Age" aria-label="Age" aria-describedby="Age" required>
                        </div>
                    </div>
                    <div class="row">
                       <div class="col form-inline" >
                            <span class="input-group-text mr-4" id="age">Gender</span>
                            <div class="form-check mr-2">
                                <input class="form-check-input" type="radio" name="gender" id="male" required>
                                <label class="form-check-label" for="male">Male</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="gender" id="female" value="female">
                                <label class="form-check-label" for="female">Female </label>
                            </div>
                       </div>
                       <div class="col form-inline" >
                        <span class="input-group-text mr-4" id="status">Status</span>
                        <div class="form-check mr-2">
                            <input class="form-check-input" type="radio" name="status" id="infected" value="2" required>
                            <label class="form-check-label" for="infected">Infected</label>
                        </div>
                        <div class="form-check mr-2">
                            <input class="form-check-input" type="radio" name="status" id="noninfected" value="0">
                            <label class="form-check-label" for="noninfected">NoneInfected </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="status" id="riskinfected" value="1">
                            <label class="form-check-label" for="riskinfected">Risk of infected</label>
                        </div>
                   </div>
                    </div>
                    <div class="row">
                        <div class="input-group mt-2 mb-1 col">
                            {{-- INPUT Latitude--}}
                            <div class="input-group-prepend">
                                <span class="input-group-text">Latitude</span>
                              </div>
                              <input id="latitude" type="float" class="form-control mr-3" placeholder="Latitude" aria-label="Latitude" aria-describedby="Latitude" name="latitude" required>
                        </div>
                        
                        <div class="input-group mt-2 mb-1 col">
                            {{-- INPUT Longitude--}}
                            <div class="input-group-prepend">
                                <span class="input-group-text">Longitude</span>
                            </div>
                            <input id="longitude" type="float" class="form-control" placeholder="Longitude" aria-label="Longitude" aria-describedby="Longitude" name="longitude" required>
                        </div>
                        <div class="input-group mt-2 mb-1 col">
                            {{-- CLICK to assign location --}}
                            <button id="location" type="button" class="btn btn-primary">GET LOCATION</button>
                        </div>

                    </div>
                </div>
                <button type="submit" class="btn btn-success">SUBMIT</button>
            </form>
            
            
         </div>
        
        </div>
 
        <!-- script -->
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        <script type="text/javascript" src="{{ asset('js/app.js') }}"></script>
    </body>
            
 
    



        
        
    
</html>
