<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Laravel</title>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    
    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet" type="text/css" >
</head>
 <!-- NAV bar -->
 <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="/">COVID19</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
  
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item ">
          <a class="nav-link" href="/">Add User <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/update_location">update_location</a>
        </li>
        <li class="nav-item ">
          <a class="nav-link " href="/infected_add">infected_add</a>
        </li>
        <li class="nav-item active">
          <a class="nav-link text-primary" href="/infected_list">infected_list</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/risk_infected_add">risk_infected_add</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/risk_infected_list">risk_infected_list</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/api_report">API REPORT</a>
      </li>
    </div>
  </nav>

 
  <div class="container">
    <h1>INFECTED HISTORY</h1>
  
        <table  class="text-center">
            <th>id</thead>
            <th>infected date</th>
            <th>cure date</th>
            @foreach ($infected_list as $item)
            <tr>
                <td>  {{$item['id']}} </td>
                <td>  {{$item['infected_date']}}  </td>
                <td>  {{$item['cure_date']}}  </td>
            </tr>
        @endforeach
        </table>
  </div>
  

   <!-- script -->
   <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
   <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
   <script type="text/javascript" src="{{ asset('js/app.js') }}"></script>