




$( document ).ready(function() {
  
  //Date setting
  var monthNames = [ "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December" ];
  var dayNames= ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]

  var newDate = new Date();
  newDate.setDate(newDate.getDate());    
  $('#Date').html(dayNames[newDate.getDay()] + " " + newDate.getDate() + ' ' + monthNames[newDate.getMonth()] + ' ' + newDate.getFullYear());

    $('#select_user').change(function() {
      //Set user id to prevent self check
      $('#select_id').val($('#select_user').val())
     });


     

    $( "#location" ).click(function() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position){
                // console.log("Latitude: " + position.coords.latitude + "\nLongitude: " + position.coords.longitude);
                $( "#latitude").val(parseFloat(position.coords.latitude).toFixed(2));
                $( "#longitude").val(parseFloat(position.coords.longitude).toFixed(2));
                cur_la = position.coords.latitude.toFixed(2)//current latitude
                cur_lo = position.coords.longitude.toFixed(2)//current longitude
                console.log("Update location to : "+cur_la+","+cur_lo);       //Show current location
                 //Near infect check
                  // for(i=1;i<=$('#rows_count').val();i++){
                  //   //find distance with infected only
                  //   if($('#status'+i).val()==2){
                  //     //Self check prevent condition
                  //     if( i != $('#select_id').val()){
                  //       other_la = $('#la'+i).val();
                  //       other_lo = $('#lo'+i).val();

                  //       //Find distance
                  //       diff_la = Math.abs(cur_la-other_la);
                  //       diff_lo = Math.abs(cur_lo-other_lo);
            
                  //       //Distance find
                  //       distance = (Math.sqrt( Math.pow(diff_la,2)+Math.pow(diff_lo,2))*1000).toFixed(2);
                  //       //log distance
                  //       // console.log("Distance form User "+i+" :"+distance+ ' m');
                  //       console.log("DISTANCE"+distance);

                  //       //Risk of infected alert
                  //       if(distance<=14.14){
                  //         alert("Infected near you. You are risk of infect from this moment")
                  //         //Change status
                  //         $('#changed_status').val(1);
                  //       }
                  //     }
                  //   }
                  // }
              });
          } else { 
            alert("Geolocation is not supported by this browser.");
          }
      });

      // update_submit
      $( "#update_submit" ).click(function() {
        console.log("UPDATE LOCATION");

                cur_la = $( "#latitude" ).val()//current latitude
                cur_lo = $( "#longitude" ).val()//current longitude
                console.log("Update location to : "+cur_la+","+cur_lo);       //Show current location
                 //Near infect check
                  for(i=1;i<=$('#rows_count').val();i++){
                    //find distance with infected only
                    if($('#status'+i).val()==2){
                      //Self check prevent condition
                      if( i != $('#select_id').val()){
                        other_la = $('#la'+i).val();
                        other_lo = $('#lo'+i).val();

                        //Find distance
                        diff_la = Math.abs(cur_la-other_la);
                        diff_lo = Math.abs(cur_lo-other_lo);
            
                        //Distance find
                        distance = (Math.sqrt( Math.pow(diff_la,2)+Math.pow(diff_lo,2))*1000).toFixed(2);
                        //log distance
                        // console.log("Distance form User "+i+" :"+distance+ ' m');
                        console.log("DISTANCE"+distance);

                        //Risk of infected alert
                        if(distance<=14.14){
                          alert("Infected near you. You are risk of infect from this moment")
                          //Change status
                          $('#changed_status').val(1);
                        }
                      }
                    }
                  }

      });
      //API report part
      //Convert to % form cur_user cur_infected
      current_infect = ($('#cur_infected').val()/$('#cur_user').val())*100;
      current_infect = current_infect.toFixed(2)
      $('#show_infected').html(current_infect);
     

});