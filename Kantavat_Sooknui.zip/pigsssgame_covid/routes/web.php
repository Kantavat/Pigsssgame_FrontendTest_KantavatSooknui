<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\dummyAPI;
use App\Http\Controllers\infectlist;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
// save and edit data
Route::post('add',[dummyAPI::class,'add']);
Route::post('edit',[dummyAPI::class,'update']);
Route::post('edit_infected',[infectlist::class,'infected_update']);
Route::post('edit_risk_infected',[infectlist::class,'risk_update']);

//For change page
Route::get('/update_location',[dummyAPI::class,'update_location']);
Route::get('/infected_add',[dummyAPI::class,'infected_add']);
Route::get('/infected_list',[dummyAPI::class,'infected_list']);
Route::get('/risk_infected_add',[dummyAPI::class,'risk_infected_add']);
Route::get('/risk_infected_list',[dummyAPI::class,'risk_infected_list']);
Route::get('/api_report',[dummyAPI::class,'api_report']);


//Get data from DataBase
Route::get('update_location',[dummyAPI::class,'show']);
Route::get('infected_add',[infectlist::class,'show']);
Route::get('infected_list',[infectlist::class,'show_list']);
Route::get('risk_infected_add',[infectlist::class,'risk_list']);
Route::get('risk_infected_list',[infectlist::class,'show_risk_list']);

//API REPORT get data
Route::get('api_report',[dummyAPI::class,'show_api']);