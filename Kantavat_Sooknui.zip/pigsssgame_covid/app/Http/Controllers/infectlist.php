<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\tests;
use App\Models\infected_list;
use App\Models\risk_infected_list;

class infectlist extends Controller
{
    //Post data
    //post to infected_list
    function infected_update(Request $req){
        $infected_list = new infected_list;
        $infected_list->id  = $req->id;
        $infected_list->infected_date  = $req->infected_date;
        $infected_list->cure_date  = $req->cure_date;

        $infected_list->save();
 
        return redirect('/');
    }
    //post to risk_infected_list
    function risk_update(Request $req){
      $risk_infected_list = new risk_infected_list;
      $risk_infected_list->id  = $req->id;
      $risk_infected_list->start_quarantine_date  = $req->start_date;
      $risk_infected_list->stop_quarantine_date  = $req->stop_date;

      $risk_infected_list->save();

      return redirect('/');
  }

      //Get data from tests table
      public function show()
      {
          $data = tests::all();
          $count_rows = tests::count();
          $infected_rows = tests::where('status','=','2')->count();       //Counted infected only
          return view('infected_add',['test'=> $data,'test_rows'=>$count_rows,'infected_rows'=>$infected_rows]);
      }
      public function show_list()
      {
        $data = infected_list::all();
        $count_rows = infected_list::count();
        return view('infected_list',['infected_list'=> $data,'test_rows'=>$count_rows]);
      }
      public function risk_list()
      {
        $data = tests::all();
        $count_risk = tests::where('status','=','1')->count();       //Counted risk of infected only
        return view('risk_infected_add',['data'=> $data,'count_risk'=>$count_risk]);
      }

      public function show_risk_list()
      {
        $data = risk_infected_list::all();
        $count_rows = risk_infected_list::count();
        return view('risk_infected_list',['risk_infected_list'=> $data,'test_rows'=>$count_rows]);
      }
  
}
