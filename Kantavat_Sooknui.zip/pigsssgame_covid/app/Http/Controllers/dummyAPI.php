<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\tests;
use App\Models\infected_list;
use App\Models\risk_infected_list;

class dummyAPI extends Controller
{
    // function getData(){
    //     return ["name" => "anil"];
    // }

    //Get data from api
    function list($id=null){
        return $id?tests::find($id):tests::all();
    }

    //Post data API
    function add(Request $req){
       $tests = new tests;
       $tests->name = $req->name;
       $tests->age  = $req->age;
       $tests->telephone  = $req->telephone;
       $tests->gender = $req->gender;
       $tests->status = $req->status;
       $tests->latitude = $req->latitude;
       $tests->longitude = $req->longitude;

       $result = $tests->save();

       if($tests->status==2){
        return redirect('infected_add');
       }
       elseif($tests->status==1){
        return redirect('risk_infected_add');
       }
       else{
        return redirect('/');
       }
    }

    //Get data from tests table
    public function show()
    {
        $data = tests::all();
        $count_rows = tests::count();
        $infected_rows = tests::where('status','=','2')->count();       //Counted infected only
        return view('update_location',['test'=> $data,'test_rows'=>$count_rows,'infected_rows'=>$infected_rows]);
    }
    // show_api part 
    public function show_api()
    {
        $data = tests::all();
        $infected_by_date = tests::where('status','=','2')->orderBy('updated_at','asc')->get();
        $risk_infected = tests::where('status','=','1')->get();

        $count_rows = tests::count();
        $cumulative_infect = infected_list::count();
        $count_noninfected = tests::where('status','=','0')->count();       //Counted noninfected only
        $count_riskinfected = tests::where('status','=','1')->count();      //Counted risk of infected only
        $count_infected = tests::where('status','=','2')->count();          //Counted infected only
        return view('api_report',['data'=> $data,'count_rows'=>$count_rows,
                                        'count_infected'=>$count_infected,
                                        'cumulative_infect'=>$cumulative_infect,
                                        'count_noninfected'=>$count_noninfected,
                                        'count_riskinfected'=>$count_riskinfected,
                                        'infected_by_date'=>$infected_by_date,
                                        'risk_infected'=>$risk_infected
                                        ]);
    }
     //Post data API
     function update(Request $req){
        $data = tests::find($req->id);
        $data->latitude = $req->latitude;
        $data->longitude = $req->longitude;
        $data->status = $req->status;

        $data->save();
        return redirect('update_location');
        
     }

    // View page update_location
    function update_location(){
        return view('update_location');
    }
    // View page infected history
    function infected_add(){
        return view('infected_add');
    }
    function infected_list(){
        return view('infected_list');
    }
    function risk_infected_add(){
        return view('risk_infected_add');
    }
    function risk_infected_list(){
        return view('risk_infected_list');
    }
    function api_report(){
        return view('api_report');
    }
}
